void init_ADC_y_timer0(void);
void ADC_IRQHandler(void);
void record(void);
