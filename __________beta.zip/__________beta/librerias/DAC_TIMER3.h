

void TIMER3_IRQHandler(void);
void init_DAC_y_TIMER3(void);
void play_recorded(void);
void play_alarm(void);
