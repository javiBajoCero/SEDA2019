
void config_timer1_CAP10_timer2_CAP20(void);
void config_pwm_1y2(void);
void set_pwmA(int ciclo);
void set_pwmB(int ciclo);
void moveLinecm(int centimeters);
void turnDegrees(int degrees);
void onetimeUARTruedas(void);
void onetimeBLUETOOTHruedas(void);
void onetimePANTALLAruedas(void);
void TIMER2_IRQHandler(void);
void TIMER1_IRQHandler(void);
