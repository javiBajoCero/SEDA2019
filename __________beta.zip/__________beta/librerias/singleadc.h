

void ADC_IRQHandler(void);
void init_ADC(void);
void snap_adc(void);
