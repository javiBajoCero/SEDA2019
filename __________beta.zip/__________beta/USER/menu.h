

void 	initScreenStateMachine(void);

void screenStateMachine(void);

void screenMessage(void);
void screenMessageIP(void);
void onetimeWEBruedas(void);

void	imprime_distancia_motores(void);
void  imprime_temperatura_voltaje(void);
void imprime_distancia_motores(void);
void imprime_temperatura_voltaje(void);
void imprime_velocidad_motores(void);

